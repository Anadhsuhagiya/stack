import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:stack/first.dart';

import 'Model.dart';
import 'SignUp.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController Username = TextEditingController();
  TextEditingController Password = TextEditingController();

  FirebaseDatabase database = FirebaseDatabase.instance;
  List<Map> data = [];

  bool emailerror = false;
  bool passerror = false;
  bool hidepass = true;

  String ImagePath = "";

  String emailmsg = "";
  String passmsg = "";

  var Height, Width;

  @override
  Widget build(BuildContext context) {
    Height = MediaQuery.of(context).size.height;
    Width = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Scaffold(
          body: Stack(
        children: [
          Container(
            height: double.infinity,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    colors: [Color(0xff030165), Color(0xff82b1e8)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight)),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 30,
                  ),
                  SizedBox(
                    height: Height * 0.15,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: 0),
                        child: Text(
                          "Login",
                          style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              fontSize: 40,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextField(
                      onChanged: (value) {
                        print(value);
                        if (emailerror) {
                          if (value.isNotEmpty) {
                            setState(() {
                              emailerror = false;
                            });
                          }
                        }
                      },
                      controller: Username,
                      keyboardType: TextInputType.text,
                      style: GoogleFonts.montserrat(
                          textStyle: TextStyle(color: Color(0xffffffff))),
                      decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: BorderSide(
                                  color: Color(0xffffffff), width: 1)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: BorderSide(
                                  color: Color(0xffffffff), width: 3)),
                          border: OutlineInputBorder(),
                          hintText: "Enter Username",
                          labelText: "Username",
                          labelStyle: GoogleFonts.montserrat(
                              textStyle: TextStyle(color: Color(0xffffffff))),
                          errorText: emailerror ? emailmsg : null,
                          prefixIcon: Icon(
                            Icons.email_rounded,
                            color: Color(0xffffffff),
                          )),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 10, right: 10, bottom: 10, top: 3),
                    child: TextField(
                      onChanged: (value) {
                        print(value);
                        if (passerror) {
                          if (value.isNotEmpty) {
                            setState(() {
                              passerror = false;
                            });
                          }
                        }
                      },
                      controller: Password,
                      obscureText: hidepass,
                      style: GoogleFonts.montserrat(
                          textStyle: TextStyle(color: Color(0xffffffff))),
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: BorderSide(
                                  color: Color(0xffffffff), width: 1)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: BorderSide(
                                  color: Color(0xffffffff), width: 3)),
                          border: OutlineInputBorder(),
                          hintText: "Enter Your Password",
                          labelText: "Password",
                          labelStyle: GoogleFonts.montserrat(
                              textStyle: TextStyle(color: Color(0xffffffff))),
                          suffixIcon: IconButton(
                              onPressed: () {
                                hidepass = !hidepass;
                                setState(() {});
                              },
                              icon: hidepass
                                  ? Icon(
                                      Icons.visibility,
                                      color: Color(0xffffffff),
                                    )
                                  : Icon(
                                      Icons.visibility_off,
                                      color: Color(0xffffffff),
                                    )),
                          errorText: passerror ? passmsg : null,
                          prefixIcon: Icon(
                            Icons.lock,
                            color: Color(0xffffffff),
                          )),
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  InkWell(
                    onTap: () async {
                      String username = Username.text.trim();
                      String password = Password.text.trim();

                      String Username_Compare = "";
                      String Password_Compare = "";
                      String Name_Login = "";

                      if (username.isEmpty) {
                        emailerror = true;
                        emailmsg = "Enter Uesrname ";
                        setState(() {});
                      } else if (password.isEmpty) {
                        passerror = true;
                        passmsg = "Enter your password";
                        setState(() {});
                      } else {
                        showDialog(
                          context: context,
                          builder: (context) {
                            return SimpleDialog(
                              children: [
                                Container(
                                  height: 60,
                                  child: ListTile(
                                    leading: Container(
                                      height: 45,
                                      width: 45,
                                      alignment: Alignment.center,
                                      child: CircularProgressIndicator(color: Colors.black,),
                                    ),
                                    title: Text(
                                      "Please Wait ...",
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                )
                              ],
                            );
                          },
                        );

                        DatabaseEvent dv = await database.ref('User').once();
                        Map temp = dv.snapshot.value as Map;
                        data.clear();
                        temp.forEach((key, value) {
                          data.add(value);
                          print(data);
                        });

                        for (int i = 0; i < data.length; i++) {
                          if (username == data[i]['email'] &&
                              password == data[i]['pass']) {
                            Username_Compare = data[i]['email'];
                            Password_Compare = data[i]['pass'];
                            Name_Login = data[i]['name'];
                            print("Username_Compare : $Username_Compare");
                            print("Password_Compare : $Password_Compare");
                            print("Name_Login : $Name_Login");
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => first(),));
                          }
                        }

                        if (username == Username_Compare &&
                            password == Password_Compare) {
                          await Model.prefs!.setString('Name', Name_Login);
                          await Model.prefs!
                              .setString('Email', Username_Compare);
                          // await Model.prefs!.setString('Mobile', Mobile!);
                          await Model.prefs!.setInt('registered', 1);


                        } else {
                          Fluttertoast.showToast(
                              msg: "Insert Valid Email and Password",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.red,
                              textColor: Colors.white,
                              fontSize: 15.0);
                        }
                      }
                    },
                    child: Container(
                      height: 50,
                      width: 120,
                      alignment: Alignment.center,
                      decoration: ShapeDecoration(
                          color: Color(0xff030165),
                          shadows: [
                            BoxShadow(
                                blurRadius: 7,
                                spreadRadius: 1,
                                offset: Offset(0, 3),
                                color: Colors.black.withOpacity(0.4))
                          ],
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                      child: Text(
                        "Login",
                        style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ),
                  SizedBox(height: 30,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "You have no Account ? ",
                        style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                          color: Color(0xffffffff),
                          fontSize: 15,
                        )),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pushReplacement(context, MaterialPageRoute(
                            builder: (context) {
                              return SignUp();
                            },
                          ));
                        },
                        child: Text(
                          "Sign Up",
                          style: GoogleFonts.montserrat(
                              textStyle: TextStyle(
                                  color: Color(0xff030165),
                                  fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      )),
    );
  }
}
