import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:stack/first.dart';

import 'Login.dart';
import 'Model.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  FirebaseDatabase database = FirebaseDatabase.instance;
  List<Map> data = [];

  var Height, Width;

  TextEditingController Name = TextEditingController();
  TextEditingController Email = TextEditingController();
  TextEditingController PhoneNumber = TextEditingController();
  TextEditingController Password = TextEditingController();
  TextEditingController DatePick = TextEditingController();

  int textLength = 0;
  int maxLength = 10;

  bool hidepass = true;

  @override
  Widget build(BuildContext context) {
    Height = MediaQuery.of(context).size.height;
    Width = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              height: double.infinity,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [Color(0xff030165), Color(0xff82b1e8)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight)
                  // image: DecorationImage(
                  //     image: AssetImage('photos/bgablur.jpg'),
                  //     fit: BoxFit.cover,
                  //     opacity: 0.8)
                  ),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 0),
                          child: Text(
                            "Sign Up",
                            style: GoogleFonts.montserrat(
                              textStyle: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 40,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: TextField(
                        controller: Name,
                        keyboardType: TextInputType.name,
                        textCapitalization: TextCapitalization.words,
                        style: TextStyle(color: Color(0xffffffff)),
                        decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 1)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 3)),
                            border: OutlineInputBorder(),
                            hintText: "Enter Name",
                            labelText: "Name",
                            labelStyle: TextStyle(color: Color(0xffffffff)),
                            prefixIcon: Icon(
                              Icons.person,
                              color: Color(0xffffffff),
                            )),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: TextField(
                        controller: Email,
                        keyboardType: TextInputType.text,
                        textCapitalization: TextCapitalization.sentences,
                        style: TextStyle(color: Color(0xffffffff)),
                        decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 1)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 3)),
                            border: OutlineInputBorder(),
                            hintText: "Enter Email Address",
                            labelText: "Email",
                            labelStyle: TextStyle(color: Color(0xffffffff)),
                            prefixIcon: Icon(
                              Icons.email_rounded,
                              color: Color(0xffffffff),
                            )),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: TextField(
                        controller: PhoneNumber,
                        keyboardType: TextInputType.phone,
                        textCapitalization: TextCapitalization.sentences,
                        style: TextStyle(color: Color(0xffffffff)),
                        maxLength: 10,
                        decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 1)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 3)),
                            counter: Offstage(),
                            suffixText:
                                '${textLength.toString()}/${maxLength.toString()}',
                            hintText: "Enter Your Contact",
                            labelText: "Contact",
                            labelStyle: TextStyle(color: Color(0xffffffff)),
                            prefixIcon: Icon(
                              Icons.phone,
                              color: Color(0xffffffff),
                            )),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 10, right: 10, bottom: 15),
                      child: TextField(
                        onTap: () async {
                          DateTime? date = await showDatePicker(
                              context: context,
                              builder: (context, child) {
                                return Theme(
                                  data: Theme.of(context).copyWith(
                                    colorScheme: ColorScheme.light(
                                      primary: Color(0xff030165),
                                      // header background color
                                      onPrimary: Colors.white,
                                      // header text color
                                      onSurface:
                                          Colors.black, // body text color
                                    ),
                                    textButtonTheme: TextButtonThemeData(
                                      style: TextButton.styleFrom(
                                        primary: Color(
                                            0xff030165), // button text color
                                      ),
                                    ),
                                  ),
                                  child: child!,
                                );
                              },
                              initialDate: DateTime.now(),
                              firstDate: DateTime(1960),
                              lastDate: DateTime(2024));
                          DatePick.text =
                              "${date?.day} - ${date?.month} - ${date?.year}";
                          setState(() {});
                        },
                        controller: DatePick,
                        keyboardType: TextInputType.text,
                        autofocus: false,
                        readOnly: true,
                        textCapitalization: TextCapitalization.sentences,
                        style: TextStyle(color: Color(0xffffffff)),
                        decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 1)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 3)),
                            border: OutlineInputBorder(),
                            hintText: "Pick Your BirthDate",
                            suffixIcon: IconButton(
                                onPressed: () async {
                                  DateTime? date = await showDatePicker(
                                      context: context,
                                      initialDate: DateTime.now(),
                                      firstDate: DateTime(1960),
                                      lastDate: DateTime(2024));
                                  DatePick.text =
                                      "${date?.day} / ${date?.month} / ${date?.year} / ";
                                  setState(() {});
                                },
                                icon: Icon(
                                  Icons.calendar_today,
                                  color: Color(0xffffffff),
                                )),
                            labelText: "BirthDate",
                            labelStyle: TextStyle(color: Color(0xffffffff)),
                            prefixIcon: Icon(
                              Icons.date_range,
                              color: Color(0xffffffff),
                            )),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 10, right: 10, bottom: 10, top: 3),
                      child: TextField(
                        controller: Password,
                        obscureText: hidepass,
                        textCapitalization: TextCapitalization.sentences,
                        style: TextStyle(color: Color(0xffffffff)),
                        keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 1)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(
                                    color: Color(0xffffffff), width: 3)),
                            border: OutlineInputBorder(),
                            hintText: "Enter Your Password",
                            labelText: "Password",
                            labelStyle: TextStyle(color: Color(0xffffffff)),
                            suffixIcon: IconButton(
                                onPressed: () {
                                  hidepass = !hidepass;
                                  setState(() {});
                                },
                                icon: hidepass
                                    ? Icon(
                                        Icons.visibility,
                                        color: Color(0xffffffff),
                                      )
                                    : Icon(
                                        Icons.visibility_off,
                                        color: Color(0xffffffff),
                                      )),
                            prefixIcon: Icon(
                              Icons.lock,
                              color: Color(0xffffffff),
                            )),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Already Registered ? ",
                          style:
                              TextStyle(color: Color(0xffffffff), fontSize: 16),
                        ),
                        TextButton(
                            onPressed: () {
                              Navigator.pushReplacement(context,
                                  MaterialPageRoute(
                                builder: (context) {
                                  return Login();
                                },
                              ));
                            },
                            child: Text("Login",
                                style: TextStyle(
                                    color: Color(0xff030165), fontSize: 20))),
                        SizedBox(
                          width: 30,
                        ),
                        InkWell(
                          onTap: () async {
                            String name = Name.text.trim();
                            String Phone = PhoneNumber.text.trim();
                            String email = Email.text.trim();
                            String pass = Password.text.trim();
                            String Date = DatePick.text.trim();

                            // Map m = {'name': Name, 'phone': Phone, 'email': Email, 'pass': pass};

                            bool emailValid = RegExp(
                                    r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                .hasMatch(email);
                            bool passValid = RegExp(
                                    r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$')
                                .hasMatch(pass);

                            showDialog(
                              context: context,
                              builder: (context) {
                                return SimpleDialog(
                                  children: [
                                    Container(
                                      height: 60,
                                      child: ListTile(
                                        leading: Container(
                                          height: 45,
                                          width: 45,
                                          alignment: Alignment.center,
                                          child: CircularProgressIndicator(),
                                        ),
                                        title: Text(
                                          "Please Wait ...",
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    )
                                  ],
                                );
                              },
                            );

                            String? key = database.ref('User').push().key;
                            database.ref('User').child(key!).set({
                              'name': name,
                              'Phone': Phone,
                              'email': email,
                              'pass': pass,
                              'date': Date,
                              'key': key
                            });

                            DatabaseEvent dv =
                                await database.ref('User').once();
                            Map temp = dv.snapshot.value as Map;
                            data.clear();
                            temp.forEach((key, value) {
                              data.add(value);
                              print(data);
                            });
                            setState(() {});

                            String NAME = "";
                            String EMAIL = "";
                            for (int i = 0; i < data.length; i++) {
                              if (name == data[i]['name'] &&
                                  email == data[i]['email']) {
                                NAME = data[i]['name'];
                                EMAIL = data[i]['email'];
                                print("NAME : $NAME");
                                print("EMAIL : $EMAIL");
                                Navigator.pushReplacement(
                                    context,
                                    PageRouteBuilder(
                                      transitionDuration:
                                          Duration(milliseconds: 500),
                                      pageBuilder: (context, animation,
                                              secondaryAnimation) =>
                                          first(),
                                      transitionsBuilder: (context, animation,
                                          secondaryAnimation, child) {
                                        return FadeTransition(
                                          opacity: animation,
                                          child: child,
                                        );
                                      },
                                    ));
                              }
                            }
                            await Model.prefs!.setString('Name', NAME);
                            await Model.prefs!.setString('Email', EMAIL);
                            // await Model.prefs!.setString('Mobile', Mobile!);
                            await Model.prefs!.setInt('registered', 1);
                          },
                          child: Container(
                            height: 50,
                            width: 120,
                            alignment: Alignment.center,
                            decoration: ShapeDecoration(
                                color: Color(0xff030165),
                                shadows: [
                                  BoxShadow(
                                      blurRadius: 7,
                                      spreadRadius: 1,
                                      offset: Offset(0, 3),
                                      color: Colors.black.withOpacity(0.4))
                                ],
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10))),
                            child: Text(
                              "SignUp",
                              style: TextStyle(
                                  color: Color(0xffffffff), fontSize: 20),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
