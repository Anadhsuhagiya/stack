import 'package:shared_preferences/shared_preferences.dart';

class Model{
  static SharedPreferences? prefs;
}